// قم بتعريف متغير جلوبال لتخزين الأعضاء المحظورين
global.db.data.bannedUsers = {};

const handler = async (m, { conn, participants, usedPrefix, command }) => {
  const BANtext = `[❗] منشن الذي تريد حظره عن استخدام البوت\n\n*—◉ مثال:*\n*${usedPrefix + command} @${global.suittag}*`;
  if (!m.mentionedJid[0] && !m.quoted) return m.reply(BANtext, m.chat, { mentions: conn.parseMention(BANtext) });
  let who;
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender;
  else who = m.chat;

  // التحقق مما إذا كان المستخدم محظورًا بالفعل أم لا
  if (global.db.data.bannedUsers[who]) {
    return m.reply('*[❗𝐈𝐍𝐅𝐎❗] هذا المستخدم محظور بالفعل عن استخدام البوت!*');
  }

  // حظر المستخدم
  global.db.data.bannedUsers[who] = true;

  return m.reply(`*[✅] تم حظر المستخدم بنجاح!*`);
};

handler.command = /^بان$/i;
handler.rowner = true;
export default handler;
