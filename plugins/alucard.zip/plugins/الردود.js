// دالة لاسترجاع الردود المخزنة لمجموعة معينة
async function getResponses(chatId) {
    if (!global.db.data.responses) {
        return [];
    }
    if (!global.db.data.responses[chatId]) {
        return [];
    }
    return Object.entries(global.db.data.responses[chatId]);
}

// تعديل الأمر لعرض الردود الموجودة لمجموعة معينة
let showResponses = async (m, { conn }) => {
    let responses = await getResponses(m.chat); // استخدام معرف المجموعة لاسترجاع الردود
    if (responses.length === 0) {
        return conn.reply(m.chat, '📝 لا يوجد ردود مضافة حالياً.', m);
    } else {
        let message = '📝 *الردود الموجودة*:\n\n';
        message += responses.map(([keyword, value], index) => `${index + 1}. ${keyword}: ${value}`).join('\n');
        return conn.reply(m.chat, message, m);
    }
}

showResponses.command = 'الردود';
showResponses.tags = ['game'];
showResponses.help = ['الردود'];
showResponses.admin = true;
export default showResponses;
