let handler = async (m, { conn, usedPrefix, command }) => {
  // التأكد من وجود المتغيرات اللازمة في قاعدة البيانات الخاصة بك
  if (!global.db.data.notes) global.db.data.notes = {}
  if (!global.db.data.notes[m.sender]) global.db.data.notes[m.sender] = []

  // إذا تم إرسال أمر ملاحظه"
  if (/^ملاحظة|ملاحظه$/i.test(command)) {
      // استخراج نص الملاحظة من الرسالة
      let note = m.text.trim().split(' ').slice(1).join(' ')

      // التأكد من أنه تم إدخال ملاحظة صالحة
      if (!note) throw "يجب عليك تحديد نص الملاحظة!"

      // إضافة الملاحظة إلى قاعدة البيانات
      global.db.data.notes[m.sender].push(note)

      // إرسال رسالة تأكيد إضافة الملاحظة
      m.reply("تمت إضافة الملاحظة بنجاح!")
  }
  // إذا تم إرسال أمر "الملاحظات"
  else if (/^الملاحظات$/i.test(command)) {
      // استخراج قائمة الملاحظات
      let notes = global.db.data.notes[m.sender]

      // التأكد من وجود ملاحظات
      if (notes.length === 0) {
          m.reply("لا يوجد ملاحظات محفوظة حتى الآن!")
          return
      }

      // إنشاء رسالة عرض الملاحظات
      let message = "📝 قائمة الملاحظات:\n\n"
      for (let i = 0; i < notes.length; i++) {
          message += "${i + 1}. ${notes[i]}\n"
      }

      // إرسال رسالة عرض الملاحظات
      m.reply(message)
  }
  //إذا تم إرسال أمر عدل"
  else if (/^عدل$/i.test(command)) {
      // استخراج رقم الملاحظة المراد تعديلها
      let index = parseInt(m.text.trim().split(' ')[1])

      // استخراج الملاحظة الجديدة
      let newNote = m.text.trim().split(' ').slice(2).join(' ')

      // التأكد من أن الملاحظة المطلوب تعديلها صحيحة
      if (isNaN(index) || index < 1 || index > global.db.data.notes[m.sender].length) {
          throw "يرجى تحديد رقم صحيح للملاحظة المراد تعديلها!"
      }

      // تعديل الملاحظة
      global.db.data.notes[m.sender][index - 1] = newNote

      // إرسال رسالة تأكيد تعديل الملاحظة
      m.reply("تم تعديل الملاحظة بنجاح!")
  }
  //ذا تم إرسال أمر "حذف ملاحظه"
  else if (/^حذف-ملاحظة|حذف-ملاحظه$/i.test(command)) {
      // استخراج رقم الملاحظة المراد حذفها
      let index = parseInt(m.text.trim().split(' ')[1])

      // التأكد من أن الملاحظة المطلوب حذفها صحيحة
      if (isNaN(index) || index < 1 || index > global.db.data.notes[m.sender].length) {
          throw "يرجى تحديد رقم صحيح للملاحظة المراد حذفها!"
      }

      // حذف الملاحظة
      global.db.data.notes[m.sender].splice(index - 1, 1)

      // إرسال رسالة تأكيد حذف الملاحظة
      m.reply("تم حذف الملاحظة بنجاح!")
  }
  // إذا تم إرسال أمر "الملاحظه"
  else if (/^الملاحظة|الملاحظه$/i.test(command)) {
      // استخراج رقم الملاحظة المراد عرضها
      let index = parseInt(m.text.trim().split(' ')[1])

      // التأكد من أن الملاحظة المطلوب عرضها صحيحة
      if (isNaN(index) || index < 1 || index > global.db.data.notes[m.sender].length) {
          throw "يرجى تحديد رقم صحيح للملاحظة المراد عرضها!"
      }

      // عرض الملاحظة المحددة
      m.reply(global.db.data.notes[m.sender][index - 1])
  }
}

handler.help = ['اضف-ملاحظة', 'عرض-ملاحظات', 'تعديل-ملاحظة', 'حذف-ملاحظة', 'عرض-ملاحظة']
handler.tags = ['notes']
handler.command = /^(ملاحظة|ملاحظه|الملاحظات|عدل|حذف-ملاحظة|حذف-ملاحظه|الملاحظة|الملاحظه)$/i
export default handler