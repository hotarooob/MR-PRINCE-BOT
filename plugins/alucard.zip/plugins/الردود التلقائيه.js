let handler = m => m
handler.all = async function (m) {
    let chat = global.db.data.chats[m.chat]
    let responses = global.db.data.responses[m.chat]; // تغيير هنا لاستخدام معرف المجموعة

    // التحقق مما إذا كانت الرسالة تحتوي على أي كلمة مفتاحية موجودة في responses
    for (let keyword in responses) {
        if (new RegExp(`^\\${keyword}$`, 'i').test(m.text)) {
            let response = responses[keyword][0]; // الرد المخزن للكلمة المفتاحية
            await conn.reply(m.chat, response, m);
            return; // للخروج من الحلقة بمجرد العثور على الكلمة المفتاحية
        }
    }
}

export default handler
