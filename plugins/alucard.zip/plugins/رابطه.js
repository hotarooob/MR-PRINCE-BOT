const handler = async (m, { conn, text }) => {
  if (!text && !m.quoted) throw '*منشن شخص أو اكتب رقمه بعد أمر الرابط*';

  // التحقق مما إذا كانت الرسالة تحتوي على إجابة
  const quotedMessage = m.quoted ? m.quoted : null;

  // استخراج رقم الهاتف من الرسالة المُقتبَسة إذا كان متوفرًا
  const phoneNumber = quotedMessage ? quotedMessage.sender.split('@')[0] : null;

  // إذا كانت الرسالة تحتوي على إجابة، استخدم رقم الهاتف المستهدف
  const targetNumber = phoneNumber ? phoneNumber : text;

  // بناء الرابط باستخدام رقم الهاتف
  const url = 'https://api.whatsapp.com/send?phone=+' + targetNumber;

  await conn.reply(m.chat, url, m);
};

handler.help = ['finish'];
handler.tags = ['finish'];
handler.command = /^(رابطه)$/i;
handler.rowner = true;
export default handler;