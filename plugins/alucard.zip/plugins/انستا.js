let handler = async (m, { conn, command, text }) => {
  let user = m.sender;
  let truly = `⬣━━━[ *انستا المطور* ]━━━━⬣
  
*انستا الوكارد المطور: https://www.instagram.com/ismail._.prx*
  
*❆━━━═⏣⊰🦇⊱⏣═━━━❆*
  `.trim();
  m.reply(truly, null, { mentions: [user] });
};

handler.help = ['tagged'];
handler.tags = ['fun'];
handler.command = /^(انستا)$/i;

export default handler;