let handler = async (m, { conn, participants, text }) => {
  let who = m.mentionedJid && m.mentionedJid[0];

  if (!text) throw 'يرجى تقديم رقم ولقب!';
  let nickname = text.split(' ')[1];
  if (!who || !nickname) throw 'يرجى تقديم رقم ولقب!';
  if (!participants) throw 'لا يوجد أعضاء في المجموعة!';
  let member = participants.find(v => v.id === who);
  if (!member) throw 'العضو غير موجود في المجموعة!';

  // التحقق من وجود بيانات للجروبات
  if (!global.db.data.groups) {
    global.db.data.groups = {};
  }

  // التحقق من وجود الجروب
  if (!global.db.data.groups[m.chat]) {
    global.db.data.groups[m.chat] = {
      name: `Group ${m.chat}`,
      members: {}
    };
  }

  // إضافة أو تحديث اللقب للعضو في الجروب
  global.db.data.groups[m.chat].members[who] = {
    name: member.name,
    nickname: nickname
  };

  // حفظ التغييرات في متغير البيانات العام
  // يتم تحديث البيانات تلقائيًا من خلال الاستجابة للأوامر الأخرى
  // يمكنك أيضًا استخدام طريقة أخرى لحفظ البيانات إذا كانت متاحة في نظام قاعدة البيانات الخاص بك
  // هنا، سيتم تحديث البيانات عندما يتم تنفيذ أمر آخر
};

handler.help = ['setNickname <number> <nickname>'];
handler.tags = ['group'];
handler.command = /^setnickname|حفظ$/i;
handler.admin = true;
handler.group = true;

export default handler;
